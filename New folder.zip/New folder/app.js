js
document.addEventListener('DOMContentLoaded', () => {
  const helloBtn = document.getElementById('callApiBtn');
  const helloResult = document.getElementById('apiResult');

  const ideaInput = document.getElementById('ideaInput');
  const typeSelect = document.getElementById('typeSelect');
  const blueprintBtn = document.getElementById('blueprintBtn');
  const buildBtn = document.getElementById('buildBtn');
  const builderResult = document.getElementById('builderResult');

  // Test API
  helloBtn.addEventListener('click', async () => {
    helloResult.textContent = 'Calling API...';

    try {
      const res = await fetch('/api/hello');
      const data = await res.json();
      helloResult.textContent = JSON.stringify(data, null, 2);
    } catch (err) {
      helloResult.textContent = `Error: ${err.message}`;
    }
  });

  async function callBuilder(endpoint) {
    const idea = ideaInput.value.trim();
    const type = typeSelect.value;

    if (!idea) {
      builderResult.textContent = 'Please enter an idea first.';
      return;
    }

    builderResult.textContent = 'Working...';

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idea, type })
      });

      const data = await res.json();
      builderResult.textContent = JSON.stringify(data, null, 2);
    } catch (err) {
      builderResult.textContent = `Error: ${err.message}`;
    }
  }

  blueprintBtn.addEventListener('click', () => {
    callBuilder('/api/app-builder/blueprint');
  });

  buildBtn.addEventListener('click', () => {
    callBuilder('/api/app-builder/build');
  });
});
